package hw9;

public interface State {
	public void handleInput(Calculator calc, String input);
}
